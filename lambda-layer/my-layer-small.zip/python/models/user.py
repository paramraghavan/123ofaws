from dataclasses import dataclass, field

@dataclass
class User:
    id: str
    email: str
    name: str
    role: str = "viewer"

    def is_admin(self) -> bool:
        return self.role == "admin"

    def to_dict(self) -> dict:
        return {"id": self.id, "email": self.email, "name": self.name, "role": self.role}

    @classmethod
    def from_dict(cls, data: dict) -> "User":
        return cls(id=data["id"], email=data["email"], name=data["name"], role=data.get("role", "viewer"))
