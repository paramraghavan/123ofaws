import requests

def get_json(url: str, headers: dict = None) -> dict:
    r = requests.get(url, headers=headers or {}, timeout=10)
    r.raise_for_status()
    return r.json()

def post_json(url: str, payload: dict, headers: dict = None) -> dict:
    r = requests.post(url, json=payload, headers=headers or {}, timeout=10)
    r.raise_for_status()
    return r.json()
